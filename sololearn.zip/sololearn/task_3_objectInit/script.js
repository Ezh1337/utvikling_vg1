//task 3 object initialization 05.02.24
var John = {name: "John", age: 22};
var James = {name: "James", age: 28};
console.log(John.age)