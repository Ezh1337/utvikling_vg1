//contact manager
function contact(name,number) {
    this.name = name;
    this.number = number;
}
var a = new contact("David",12345);
var b = new contact("Amy", 98765432);
a.print(contact);
