//for aas  side - mulige valg
function fjell(){
    window.location.href="ugle.html"
}
function elv(){
    window.location.href="elv.html"
}
function gaard(){
    window.location.href="gaard.html"
}function tilbake(){
    window.location.href="index.html"
}
