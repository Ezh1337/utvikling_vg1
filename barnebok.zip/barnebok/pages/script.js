//for 1 side
function videre(){
    window.location.href="kitchen.html"
}
function tilbake(){
    window.location.href="index.html"
}
//for 2 side
function videre_aas(){
    window.location.href = "aas.html"
}