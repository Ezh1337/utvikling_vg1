
function tilbake() {
    window.location.href ="siste.html"
}function aas(){
    window.location.href = "aas.html"
}